const logoutBtn = document.querySelector("#log_out")

logoutBtn.addEventListener("click", function () {
    location.href = "./lib/logout.php";
})